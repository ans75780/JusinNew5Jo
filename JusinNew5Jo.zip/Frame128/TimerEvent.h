#pragma once

__interface ITimerEvent
{
	virtual void OnTimerEvent(int _iEventNum) PURE;

};

