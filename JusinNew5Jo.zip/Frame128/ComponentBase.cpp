#include "stdafx.h"
#include "ComponentBase.h"
