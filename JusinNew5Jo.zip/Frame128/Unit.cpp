#include "stdafx.h"
#include "Unit.h"

CUnit::CUnit()
	: m_fSpeed(0.f), m_fAtk(0.f)
{
    m_bActive = true;
}

CUnit::~CUnit() {}