#pragma once
#include "Component.h"
class CMovement :
    public CComponent
{
};